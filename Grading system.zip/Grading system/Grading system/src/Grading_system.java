import java.util.Scanner;
public class Grading_system {
public static void main(String[] args) {
	String name;
	int science,english,nepali;
	String role = null;
	int score;
	Scanner scan = new Scanner(System.in);
	System.out.print("Enter Your name:");
	name = scan.nextLine();
	if(name.toLowerCase().equals("pratik bhusal")) {
		System.out.println("Welcome "+ name + " to our system as teacher");
		role="teacher";
	}
	else {
		System.out.println("Welcome "+ name + " to our system as student");
	}
	Scanner scan1 = new Scanner(System.in);
	System.out.print("Enter Your marks in Science:");
	science = scan.nextInt();
	Scanner scan2 = new Scanner(System.in);
	System.out.print("Enter Your marks in English:");
	english = scan.nextInt();
	Scanner scan3 = new Scanner(System.in);
	System.out.print("Enter Your marks in Nepali:");
	nepali = scan.nextInt();
	if(role != "teacher") {
	if(science < 40 || english < 40 || nepali < 40) {
		System.out.println("You are failed in overall");
	}
	if(science > 40 && english > 40 && nepali > 40) {
		System.out.println("You are passed");
	}
}
	else {
		System.out.println("cannot calculate progress, you are a teacher");
	}
	}
	
}
